PC^2 Project EWTeam

For information about how to setup the EWTeam project
see the file SETUP.txt

NOTE: the EWTeam project is intended to be used by CONTEST ADMINISTRATORS 
to support the ability of teams to participate in a contest using just a web browser. 
It only needs to be installed at the site HOSTING the contest; it is not necessary 
for TEAMS to install anything -- all a team needs to do is obtain the contest URL 
from the Contest Administrator and then use any web browser to connect to the contest as a team.

The EWTeam User's Guide is at: dist/doc/pc2userguide.pdf

Contact Information:
http://pc2.ecs.csus.edu/ewteam
mailto:pc2@ecs.csus.edu

How to report bugs:
http://pc2.ecs.csus.edu/projects/bugzilla

Sign up for the announcement list:
http://pc2.ecs.csus.edu/projects

End-User Licensing:
http://pc2.ecs.csus.edu/ewteam

eof README $Id: README.txt 93 2014-03-22 20:46:39Z clevengr $
